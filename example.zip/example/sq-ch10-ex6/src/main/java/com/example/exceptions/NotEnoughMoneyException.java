package com.example.exceptions;

public class NotEnoughMoneyException extends RuntimeException {
}
