package model;

public class Comment {
}
